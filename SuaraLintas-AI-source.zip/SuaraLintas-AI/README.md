# SuaraLintas AI

Prototipe aplikasi Android untuk membantu percakapan suara Bahasa Indonesia ↔ Mandarin standar.

## Status saat ini

Ini adalah **prototipe antarmuka**, belum aplikasi penerjemah lengkap. Versi ini menyediakan:
- pilihan bahasa ucapan Indonesia atau Mandarin standar;
- percobaan pengenalan ucapan melalui layanan SpeechRecognizer Android;
- pembacaan teks melalui TextToSpeech Android.

Belum tersedia:
- mesin terjemahan offline;
- deteksi bahasa otomatis;
- dukungan teruji untuk dialek seperti Kanton, Hokkien, atau Teochew;
- jaminan bahwa pengenalan suara bekerja offline pada semua perangkat.

Dukungan offline bergantung pada versi Android, layanan pengenalan suara, dan paket bahasa yang terpasang.

## Build APK dengan GitHub Actions

Workflow `.github/workflows/android.yml` membangun APK debug ketika ada push ke `main` atau dijalankan manual dari tab Actions. Setelah build berhasil, unduh artifact `SuaraLintas-AI-debug-apk`.

## Teknologi awal

- Android Java
- Android SpeechRecognizer
- Android TextToSpeech
- Gradle + GitHub Actions

## Rencana lanjutan

1. Pastikan prototipe dapat dibangun dan dijalankan.
2. Pilih dan uji model pengenalan suara lokal yang cocok untuk Android.
3. Integrasikan model terjemahan Indonesia–Mandarin yang dapat berjalan di perangkat.
4. Tambahkan deteksi bahasa, pinyin, riwayat percakapan, dan tombol percakapan dua arah.
5. Uji ukuran model, kebutuhan RAM, kecepatan, dan akurasi di perangkat sasaran.
